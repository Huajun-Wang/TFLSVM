This source code is programmed based on the algorithm described in:

H.J. Wang, W.J. Zhou, Y.H. Shao
 
A new fast ADMM for linear SVM classifier with truncated fraction loss

Please give credits to this paper if you use the code for your research.
